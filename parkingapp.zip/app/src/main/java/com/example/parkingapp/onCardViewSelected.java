package com.example.parkingapp;

public interface onCardViewSelected {
    void onCardViewSelected(String parkingName,String parkingSpace,String parkingType);
}
