package com.example.parkingapp;

import android.view.View;

import com.google.android.material.navigation.NavigationView;

public interface navigationDrawerAcess {

    NavigationView getNavigationDrawer();
}
